import QRCode from 'qrcode';
import { Appointment, Client, Settings } from '../types';

export interface InvoiceQRData {
  invoiceNum: string;
  date: string;
  clientName?: string;
  ownerName?: string;
  serviceOrPackage?: string;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  isPaid: boolean;
  clinicName?: string;
}

/**
 * Generates a short, premium, elegant, and unique invoice number.
 * Ensures the invoice number is never overly long or cluttered.
 * Format examples: INV-101, INV-0102, INV-8492, INV-7B39
 */
export function formatShortInvoiceNumber(appt?: Partial<Appointment> | null): string {
  if (!appt) return 'INV-1001';
  if (appt.invoiceNumber && appt.invoiceNumber.trim().length > 0) {
    return appt.invoiceNumber.trim();
  }

  const rawId = (appt.id || '').trim();
  if (!rawId) {
    return 'INV-1001';
  }

  // Check if ID already matches short standard format like "ap101" -> "INV-0101"
  const digitsOnly = rawId.replace(/\D/g, '');
  if (digitsOnly.length > 0 && digitsOnly.length <= 4) {
    const num = parseInt(digitsOnly, 10);
    // Format nicely as 3 or 4 digits
    return `INV-${num < 100 ? String(num).padStart(3, '0') : num}`;
  }

  // For long timestamp IDs (e.g., ap_1723498129384), produce a deterministic, short, premium 4-digit/alphanumeric code
  let hash = 5381;
  for (let i = 0; i < rawId.length; i++) {
    hash = ((hash << 5) + hash) + rawId.charCodeAt(i);
    hash |= 0;
  }
  const absHash = Math.abs(hash);
  // Pick from clean, unambiguous alphanumeric characters (no 0, O, 1, I confusion)
  const codeNum = (absHash % 9000 + 1000); // 1000 - 9999
  return `INV-${codeNum}`;
}

/**
 * Builds a structured, scannable invoice payload string for the QR code.
 * Reads cleanly in both standard smartphone camera scanners and POS barcode readers.
 */
export function buildInvoiceQRPayload(data: Partial<InvoiceQRData>): string {
  const statusStr = data?.isPaid ? 'PAID IN FULL' : 'PAYMENT DUE';
  const clinic = data?.clinicName || 'PawBook Pro Studio';
  const sub = Number(data?.subtotal ?? 0).toFixed(2);
  const taxR = Number(data?.taxRate ?? 0);
  const taxA = Number(data?.taxAmount ?? 0).toFixed(2);
  const tot = Number(data?.totalAmount ?? 0).toFixed(2);

  return [
    `=== OFFICIAL TAX INVOICE ===`,
    `Invoice: ${data?.invoiceNum || 'INV-1001'}`,
    `Studio: ${clinic}`,
    `Date: ${data?.date || ''}`,
    data?.ownerName ? `Client: ${data.ownerName}${data.clientName ? ` (Pet: ${data.clientName})` : ''}` : '',
    data?.serviceOrPackage ? `Service: ${data.serviceOrPackage}` : '',
    `Subtotal: $${sub}`,
    `US Sales Tax (${taxR}%): $${taxA}`,
    `TOTAL AMOUNT: $${tot}`,
    `Status: ${statusStr}`,
    `============================`
  ].filter(Boolean).join('\n');
}

/**
 * Generates an SVG Data URI or PNG Data URI for the QR code with zero margin so it fits edge-to-edge
 */
export async function generateInvoiceQRDataUrl(data: InvoiceQRData): Promise<string> {
  const payload = buildInvoiceQRPayload(data);
  try {
    const dataUrl = await QRCode.toDataURL(payload, {
      errorCorrectionLevel: 'M',
      margin: 0,
      width: 260,
      color: {
        dark: '#240C0B',
        light: '#FFFFFF',
      },
    });
    return dataUrl;
  } catch (err) {
    console.error('Failed to generate invoice QR code:', err);
    return '';
  }
}
